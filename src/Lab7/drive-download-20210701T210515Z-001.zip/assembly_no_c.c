#include <stdio.h>

int mostra;
					
int main()
{
	mostra = 1234;

	__asm__( 
		"ldr r3, .L2\n\t"
		"mov r2, #1\n\t"
		"str r2, [r3, #0]\n\t"
		 "ldr r3, [fp, #-16]\n\t"
		 "mov r0,r1\n\t"
	);

	return (0);
}
